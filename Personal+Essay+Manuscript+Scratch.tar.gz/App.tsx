import React, { useEffect, useMemo, useRef, useState } from "react";
import { BookOpen, KeyRound, Lock, PenLine, Plus, Trash2, X, ChevronRight, Feather, Check } from "lucide-react";

type Seg = { t: string; b?: boolean };
type Chapter = { no: string; title: string; date: string; paragraphs: Seg[][]; note?: string };

const P = (text: string): Seg[] => [{ t: text }];
const B = (text: string): Seg[] => [{ t: text, b: true }];
const MIX = (parts: [string, boolean][]): Seg[] => parts.map(([t, b]) => ({ t, b }));

const CHAPTERS: Chapter[] = [
  {
    no: "01", title: "프롤로그", date: "2026년 10월 18일",
    paragraphs: [
      B("일기를 쓰고 싶었다."),
      P("거창한 이유는 아니다. 하루가 지나면 그날 일이 어디로 갔는지 모르게 흩어지는 게 아까웠다. 교실에서 있었던 일, 복도에서 스친 말, 집에 돌아와 뒤늦게 올라오는 감정 같은 것들. 어딘가에 적어두지 않으면 나는 같은 자리를 맴돌 것 같았다."),
      P("나는 국어를 가르친다. 아이들에게 읽으라고 하고 쓰라고 한다. 그런데 정작 나는 내 글을 쓰지 않은 채 오래 보냈다. 가르치는 사람이 자기 삶은 읽지 않는다는 사실이 문득 부끄러웠다. 그래서 이 글은 교사로서의 나를 돌아보는 글이기도 하다. 잘한 날보다 못한 날이 더 많이 적힐 것이다."),
      P("매일 쓸 수 있을지는 모르겠다. 다만 매일 쓰려고는 할 것이다. 빠진 날은 빠진 채로 두겠다. 그 빈자리도 기록의 일부라고 생각하기로 했다."),
      P("정답을 찾으려 하지는 않을 것이다. 2010년에 교단에 섰으니 올해로 열일곱 번째 해다. 그만한 시간이 지났는데도 사람 사이의 일에서 자주 틀리고, 자주 억울해하고, 자주 후회한다. 그런 날의 글은 매끄럽지 않을 것이다. 쓰고 나서 지우고 싶은 날도 있을 것이다. 그래도 지우지 않기로 했다. 내 욕망도, 부끄러움도, 조금씩 바뀌어가는 모습도 그대로 남겨두고 싶다. 변한 뒤의 나만 보여주는 글은 쓰고 싶지 않다."),
      P("그러니 이것은 잘 쓴 글이 아니라 계속 쓴 글이 될 것이다. 그 정도면 시작해도 괜찮을 것 같다."),
    ],
  },
  {
    no: "02", title: "닫힌문", date: "2026년 10월 19일",
    paragraphs: [
      B("교장실 문이 닫혀 있었다."),
      P("김00 교장 선생님이 다치셨다는 소식을 들은 건 어제였다. 가볍지 않은 부상이라 일주일은 나오지 못하신다고 했다. 복도가 평소보다 조금 조용했다. 닫힌 문을 지나치는데, 이 방 주인이 다른 사람이었던 시절이 불쑥 올라왔다. 작년 가을이었다."),
      MIX([["퇴직한 교사 000. 그냥 선생님보다는 이름으로 부르고 싶은 사람. ", false], ["그는 없는 말을 만들어 사람과 사람 사이를 갈라놓았다. 적어도 나는 그렇게 느꼈다.", true], [" 그때의 억울함을 언젠가 글로 쓰리라 다짐할 정도였다. 그 다짐은 아직 글이 되지 못했다. 대신 질문 하나가 남았다. 인간관계란 무엇이며, 내게 가장 가까운 사람은 누구인가.", false]]),
      P("당일 소식을 듣고 나는 곧장 전화를 걸었다. 큰 어르신 중 한 분이지만, 작년 그 어려운 시기에 내게 먼저 손을 내밀어준 분, 김00 교장 선생님께. 다치셨다는 말을 듣자마자 망설임 없이 번호를 눌렀다는 것, 그것이 어쩌면 저 질문에 대한 답일지도 모른다고 나중에야 생각했다."),
      P("안부를 묻는 일은 낯선 일이 아니었다. 원래 자주 소통해 온 사이였다. 다만 크게 다치셨다는 소식 앞에서는 무슨 말을 먼저 해야 할지 잠시 망설여졌다. 위로는 무거워지고, 가벼운 말은 성의 없어 보인다. 결국 평소처럼 말했다. “쾌차하시면 또 전화드릴게요.” 자주 해오던 것처럼 다음을 기약하는 인사였다."),
      MIX([["전화를 끊고 요즘 읽는 책이 떠올랐다. 호리 모토코의 『싫어하는 사람을 사라지게 하는 방법』. 처음엔 ‘사라지게 한다’를 ‘없애버린다’로 읽었다. 얼마나 험한 마음으로 제목을 봤으면 그런 해석이 먼저 떠올랐을까. 부끄러웠다. 책이 말하는 건 사람을 지우는 방법이 아니라, ", false], ["내 마음속에 미움이라는 방을 만들지 않는 방법이었다.", true]]),
      P("그러고 보니 소설을 쓰겠다던 다짐도 그 방을 하나 더 짓는 일이었는지 모른다. 누군가를 논리라는 이름으로 깎아내리고, 싫어한다는 이유로 밀어내던 버릇이 떠올랐다. 나는 언제부터 이렇게 부정적인 사람이 되었을까. 아니, 어쩌면 원래 마찰을 만드는 사람이었는지도 모른다. 다만 이제는 알아차리고 조금 다른 쪽으로 몸을 틀어보려는 중이다. 책을 집어 든 것도, 안부 전화를 건 것도 같은 방향의 몸짓이다."),
      P("책 한 권 읽고 전화 한 통 했다고 사람이 달라지지는 않는다. 변했다는 걸 증명할 필요도 없다. 다만 안부를 묻는 마음이 예전보다 조금 덜 계산적이고 더 자연스러워졌다는 사실이면 충분하다."),
      P("닫힌 문을 보니 문득 그런 생각이 들었다. 인간관계란 거창한 화해나 증명이 아니라, 다쳤다는 소식에 망설임 없이 번호를 누를 수 있는가 없나의 차이인지도 모른다. 미움의 방을 하나 덜 짓고, 있는 말을 전하는 일. 그 정도면 관계는 생각보다 단순하다."),
    ],
  },
  {
    no: "03", title: "5700", date: "2026년 10월 20일",
    paragraphs: [
      B("교무실에서 한숨이 나왔다."),
      P("누가 쉬었는지는 쓰지 않겠다. 다만 그 한숨이 “5700”이라는 숫자와 함께 나왔다는 것만 적는다. 코스피 이야기였다."),
      P("올해 6월 19일, 코스피는 장중 9,385.59를 찍었다. 넉 달 뒤인 오늘은 5,768 근처다. 지난주에는 장중 5,450까지 밀려 고점 대비 40%가 넘게 빠졌다는 기사가 떴다. 숫자에 약한 국어 교사의 방식으로 번역하면, 6월에 만 원이던 것이 지금 육천 원 남짓이 된 셈이다. 인터넷 뉴스에는 미국 물가가 안 잡혀서, 금리가 더 오를까 봐, AI에 돈을 쏟아붓는데 정말 버는 게 맞느냐는 의심이 커져서, 그래서 반도체 비중이 큰 우리 시장이 더 흔들려서, 외국인이 하루에 조 단위로 팔아서, 라고 적혀 있었다. 이유가 다섯 개쯤 되면 사실 아무도 정확히 모른다는 뜻이기도 하다."),
      P("여기까지 쓰고 보니, 나는 경제 이야기를 하려던 게 아니었다."),
      P("경제 이야기를 하다 보면 정치가 끌려 나오고, 정치가 나오면 이념이 따라오고, 이념까지 오면 결국 “그래서 너는 누구냐”는 질문이 남는다. 교무실의 한숨 하나가 나를 그 질문 앞까지 데려다 놓았다."),
      MIX([["10여 년 전의 나는, 고백하자면, 꽤 선명한 사람이었다. 난민은 받아야 하고, 집값은 잡아야 하고, 가진 사람은 나눠야 하고, 차별은 없어야 한다고 믿었다. 지금도 그 문장들이 틀렸다고 생각하지는 않는다. 문제는 그 문장들을 믿는 내가 꽤 괜찮은 사람이라고 믿었다는 데 있었다. 상대는 이기적이고 나는 아니라고. ", false], ["그때 나는 이념을 가진 게 아니라 이념을 입고 있었던 것 같다.", true], [" 옷처럼. 꽤 잘 어울린다고 생각하면서.", false]]),
      MIX([["그 옷이 벗겨진 건 집을 사면서였다. 정확히는 사고 나서다. 계약서에 도장을 찍고 돌아오는 길에 나는 생각보다 기뻤고, 그 기쁨이 낯설었다. 집값이 안정되어야 한다고 말하던 사람이, 내 집값은 좀 올라도 괜찮지 않을까 하고 생각하는 데 걸린 시간은 사흘이 채 안 되었다. 그때 알았다. ", false], ["내가 바랐던 ‘집값 안정’은 사실 ‘내가 사기 전까지의 안정’이었다는 것을.", true]]),
      P("더 오래전 얘기를 해보자. 나는 매일 아침 인터넷 뉴스를 켰다. 검색사이트부터 열어 부동산면을 훑었다."),
      MIX([["더 부끄러운 기억이 있다. 10여 년 전, 서울 아파트 평균 평당 가격이 천오백만 원쯤 하던 시절이다. 나는 모델하우스 앞까지 갔다가 들어가지 않고 돌아섰다. 비싸다고 생각했다. 평당 천만 원이면 사자고 마음먹었다. 그 숫자는 어디서 나왔을까. 시세를 분석한 것도, 공사비를 따진 것도 아니었다. 그냥 내 월급으로 감당할 만한 숫자였다. ", false], ["나는 세상이 내 월급에 맞춰 내려와 주기를 기다리고 있었던 것이다.", true]]),
      P("그 사이 인건비가 오르고 자재값이 오르고, 시중에 돈이 풀리고 또 풀렸다. 돈이 풀리면 돈의 가치가 떨어지고, 가치가 떨어지면 집값은 가만히 있어도 오른 것처럼 보인다는 걸 나는 머리로는 모르면서 몸으로 배웠다. 사실 지금도 왜 그렇게 돈을 계속 풀어야 하는지 정확히는 모른다. 다만 그게 당연한 세상이 되었다는 것만 안다. 그 당연함을 모르고 ‘천만 원’을 기다렸던 나는, 어리석었다고 하기엔 억울하고, 순진했다고 하기엔 뻔뻔하다. 둘 사이 어딘가에 있던 사람이었다."),
      MIX([["그래서 이념을 말하려는 게 아니다. 좌파가 옳았는지 우파가 옳았는지는 모르겠고, 솔직히 요즘은 그 구분 자체가 낡아 보인다. 내가 말하려는 건 나의 이중성이다. 나누자고 말하면서 내 몫은 지키고 싶었던 마음, 집값이 내려가길 바라면서 그게 남의 집값이기를 바랐던 마음. ", false], ["그 마음은 좌파도 우파도 아니고, 그냥 나였다.", true], [" ", false], ["집값이 내려오기를 기다리는 동안 나는 꽤 괜찮은 사람인 척할 수 있었지만, ", false], ["그건 괜찮은 게 아니라 그냥 안 산 것뿐이었다.", true]]),
      P("돌이켜보면 그때도 경제는 어려웠다. 어렵지 않았던 때가 있었나 싶다. 지금은 국민연금까지 뉴스에 오른다. 주식이 오를 때 원칙대로 조금 팔아두었어야 했는데, 시장이 놀랄까 봐 팔기를 미뤘고, 떨어질 때 더 크게 맞았다는 비판이다. 연금 쪽은 원칙대로 팔았으면 하루 8천억씩 쏟아내야 했으니 그게 더 큰 충격이었을 거라는 말도 있다. 누가 맞는지 나는 모른다. 다만 “오를 때 조금 팔아두었어야 했다”는 문장이 어디서 많이 들어본 말 같다. 모델하우스 앞에서 돌아선 나에게 해주었어야 할 말과 정확히 반대 방향이지만, 구조는 같다. 사람은 오를 때 팔지 못하고, 내릴 때 사지 못한다. 연금도 나도."),
      P("교무실의 한숨은 금방 잦아들었다. 5교시 종이 쳤기 때문이다. 종은 코스피와 무관하게 친다. 오르내림과 상관없이 제 시간을 지키는 것이 있다는 사실이 위로가 되었다."),
    ],
  },
  {
    no: "04", title: "홍보물", date: "2026년 10월 22일",
    paragraphs: [
      P("홍보물을 챙겼다."),
      P("10월이 되면 중간고사가 끝난다. 특성화고 교사는 그때 중학교로 간다. “우리 학교에 와 달라”고 말해야 하는 시기다. 10여 년 전과는 공기가 많이 다르다. 그때는 특성화고 인기가 대단해서 열을 올리지 않아도 학생이 왔다. 지금은 학생 수가 줄었고, 인기도 식었다. 사이클이라는 게 있나 보다. 내가 고등학교 다니던 때 상고나 공고가 좋은 대접을 받지 못하던 시절로 돌아간 것 같기도 하다. 가만히 있으면 아무도 오지 않는다. 이제는 홍보가 전부인 상황이 되었다."),
      P("홍보물을 들고 차에 오르는 교사들의 마음은 저마다 다를 것이다. 나이에 따라, 정규직과 비정규직이라는 처지에 따라 이 전단 한 장의 무게가 다르다. 정년이 얼마 남지 않은 선배는 체념 섞인 의무감으로 나설 것이고, 내년에 이 학교에 있을지 모르는 기간제 교사는 무거운 마음으로 억지웃음을 짓고 있을지도 모른다."),
      P("그러면 나는 어떤 생각으로 중학교 문을 두드리는가. 진심으로 우리 학교를 좋아해서 열렬히 홍보하고 있는 걸까. 아니, 어쩌면 나도 내 몫을 해야 한다는 마음으로 가는 걸지도 모른다."),
      P("학생들 앞에서는 우리 학교의 장점과 내실을 열띠게 설명한다. 낡은 시설은 전통과 열정이라는 포장지로 덮는다. 약간의 과장도 보탠다. 하지만 나는 안다. 나조차도 페인트칠이 벗겨진 교실보다 깨끗하고 반짝이는 시설이 좋고, 수리가 밀린 낡은 기계보다 최신 교구가 넉넉한 환경에서 수업하고 싶다는 것을."),
      P("교사이기 때문에 잘 가르쳐서 원하는 진로로 이끄는 내실이 가장 중요하다고 믿는다. 나름 열심히 하고 있다. 다만 그건 교사라면 너무 당연한 일이라 밖으로 내세우기 민망하다. 그 노력은 진학이나 취업률 같은 결과로 뒤늦게 나오지만, 졸업한 제자가 중학교에 가서 나 대신 내 직장을 칭찬해 주는 기적 같은 일은 일어나지 않는다."),
      MIX([["결국 중학생의 시선을 끄는 건 깨끗한 환경, 최신 시설, 흥미로운 전공이다. 그리고 이 모든 것은 결국 돈이다.", true], [" 어디서 예산이 뚝 떨어지지 않는 한, 노후화된 시설을 하루아침에 바꿀 수는 없다.", false]]),
      B("나조차도 번듯한 환경에서 일하고 싶어 하면서, 열여섯 살 아이들에게는 눈에 보이지 않는 내실을 보라고 말한다. 뻔히 아는 현실을 두고 좋은 말만 골라 하는 내 모습이 좀 멋쩍고 이중적이다. 다만 어쩌겠는가. 그것이 지금 내가 해야 할 일이다."),
      B("나는 오늘도 내 몫의 뻔뻔함과 과장을 챙겨 들고 중학교 교무실 문을 연다."),
    ],
  },
  {
    no: "05", title: "금요일", date: "2026년 10월 23일",
    paragraphs: [
      P("교무실이 반쯤 비어 있었다."),
      P("금요일 오후 세 시다. 누구도 눈치를 보지 않고, 누구도 눈치를 주지 않는다. 작년 이 시간이면 상상도 못 할 풍경이다. 그때는 출퇴근할 때 본인에게 직접 인사하라거나, 금요일 조퇴나 연가는 자제하라는 말이 돌았다. 그 말을 돌게 한 사람은 가까이서 보면 엄격했고, 멀리서 보면 위압적이었다. 아니, 어쩌면 나는 가까이서도 위압적이라고 느꼈는지도 모른다."),
      P("그는 교사들에게 예의를 강압적으로 요구했고, 권위적인 모습을 자주 보였다. 다른 학교 관리자는 퇴직할 때 어떤 대우를 받았고 꽃다발은 몇 개를 받았는지 같은 이야기를 했다. 마음에 들지 않으면 어떻게든 꼬투리를 잡으려 했고, 차별받는다고 느끼는 교사도 많았다. 그 기준이 무엇인지 우리는 알 수 없었다."),
      B("우리는 뒤에서 욕을 하면서도 그의 말을 아주 비굴하게 잘 따르고 있었다. 적어도 나는 그랬다. 금요일 오후면 괜히 마주치기 싫어 별실에 있었다. 돌아보면 나는 엎드려 절 받은 그분에게 참 말을 잘 듣는 대상이었다."),
      P("그와 가까이 일하던 교사들이 있었다. 그의 심기를 남보다 먼저 읽어야 했던 사람들이다. 그들은 뒤에서 오가는 교사들의 뒷담화를 들어주며 달래고 어루만졌다. 나는 그 모습을 보며 위로를 받았다. 저 사람들은 관리자와 다르다고 생각했다. 남의 이야기를 잘 들어주고, 민주적으로 해결하고, 자기 업무에만 소홀하지 않으면 괜찮다고 말하는 사람들. 지금 돌아보면 그것은 스스로를 포장하는 방식이었는지도 모른다. 그리고 그 포장 속에는 나도 들어 있었을 것이다. 들어주는 사람이 있었기에 나는 안심하고 뒤에서 욕하고 앞에서 따랐다."),
      P("그 사람은 퇴직을 했고, 그 시절을 견딘 ‘착한 사람들’이 관리자가 되었다."),
      P("풍경이 달라졌다. 관리자에게 먼저 다가가 인사하는 사람이 줄었다. 관리자들은 눈에 보이는 잘못이나 아쉬움이 있어도 잔소리나 훈계를 하지 못하는 것 같다. 속으로 끙끙대는 일이 많을 것이다. 자기가 비전으로 내세운 일을 추진하고 싶어도 업무 담당자나 후배 눈치를 보느라 움츠러든다. 과거의 관리자처럼 되지 않으려 애쓰다가, 이제는 스스로 눈치를 보는 사람이 된 것처럼 느껴진다."),
      B("권력이란 누군가를 억누를 때도 폭력적이지만, 스스로 눈치 보며 주춤거릴 때도 조직을 길 잃게 만든다."),
      B("위에서 아무 말도 내려오지 않으니, 교사들은 저마다 자기 교실 안에 작은 세계를 짓는다. 그 세계들은 서로 닿지 않는다. 누구도 틀리지 않았지만, 함께 가는 곳도 없다."),
      P("권위적인 관리자가 있을 때는 차라리 그를 안주 삼아 똘똘 뭉치며 묘한 인간미를 나누던 시절도 있었다. 그런데 이제는 인사를 건네기조차 힘든 날이 많아진 것 같다."),
      MIX([["좋은 사람이 좋은 리더가 되는 것은 아니었다.", true], [" 눈치 보는 관리자가 된 그들을 속으로 비판하다가도, 어느새 나 스스로는 어떤 모습으로 변했는지 묻게 된다.", false]]),
      P("이것도 저것도 조직의 정답은 아닌 것 같다. 정답이 있다면 진작 찾았을 것이다."),
      P("나는 어떤 사람으로 남아야 할까. 나 역시 누군가에게 욕을 먹고 싶지는 않다. 다만 조직이 방종으로 흘러가는 걸 보는 것도 힘들다. 누군가를 가르치지만 여전히 누군가의 조언이 필요한 마흔여섯이다. 교무실에 나보다 젊은 얼굴이 더 많아졌는데, 아직도 마음 한쪽은 기대고 배우고 싶다. 기대고 싶은 마음이 마흔여섯에도 그대로라는 게 웃기면서도 부끄러웠다."),
      B("비어 가는 금요일 교무실에 앉아 있다. 가고 싶으면 가도 된다. 아무도 말리지 않는다. 그런데 말리는 사람이 없다는 것과 남아 있을 이유가 없다는 것이 같은 말인지, 자꾸 되묻게 된다."),
    ],
  },
  {
    no: "06", title: "생일", date: "2026년 10월 30일",
    paragraphs: [
      B("비가 올 것 같았다. 오지 않았다. 맑다."),
      P("오늘은 내 생일이다. 1981년 양력 10월 30일, 음력으로는 10월 3일이다. 다만 주민등록상의 생일은 11월 3일이다. 할아버지가 내 이름을 짓느라 며칠을 보내는 사이 나는 11월 3일에 주민등록에 올라갔고, 내 생일은 그때부터 헷갈리기 시작했다. 어릴 때는 더욱 그랬다."),
      P("나는 어릴 때부터 내 정확한 생일을 알고 싶었다. 엄마에게 물어보면 음력 생일이라 매년 바뀐다고 했다. 왜 그래야 하는지 몰랐다. 음력이라는 게 무슨 특별한 의미가 있는 것도 아니고, 가치가 있어 보이지도 않았다. 그냥 한 날짜에 고정되어 있으면 좋겠다고 생각했다. 누가 생일을 물으면 몇 개의 날짜를 말해야 했고, 그게 귀찮았다. 그래서 그냥 11월 3일로 정해서 친구들에게 축하받고 그날 놀고 싶었는데, 그때마다 엄마는 진짜 생일이 아니라고 핀잔을 주었던 것 같다. 고등학교 때 주민등록증을 처음 받았다. 거기에는 11월 3일이 찍혀 있었다. 대한민국은 나를 그날 태어난 사람으로 알고 있었고, 엄마는 아니라고 했다."),
      MIX([["이유는 여러 가지였겠지만 나는 점점 생일에 무관심해지고 무덤덤해졌다. 내 생일에 무던해지니 남의 생일에도 관심이 없어졌다. 축하할 마음이 조금도 생기지 않았던 것 같다. 다만 공식적인 내 생일, 수능 접수나 운전면허 접수에 쓰는 날짜는 11월 3일이었고, 가족에게 생일로 인정받는 날은 여전히 음력 10월 3일이었다. ", false], ["두 날 모두 내 것이었고, 두 날 모두 내 것 같지 않았다.", true]]),
      P("성인이 되어 가끔 운세나 사주를 볼 때면 내 가짜 생일은 곤란해진다. 그 자리에서 필요한 건 진짜 태어난 날이고, 그걸 제일 정확히 아는 사람은 부모님이다. 나는 다시 묻기 시작한다. 그래서 그냥 외웠다. 81년 음력 10월 3일 자시. 내가 내 탄생에 대해 아는 건 딱 이 정도다. 여담이지만 우리 아이들이 태어났을 때 나는 잊지 않으려고 프로필에 태어난 해와 날, 시간을 입력해 두었다. 아이들만큼은 자기 생일을 남에게 묻지 않기를 바랐던 것 같다."),
      P("여전히 운세를 볼 때 말고는 내 생일은 나에게 중요한 날이 아니었다. 결혼을 하고 처가에서 챙겨 준 생일은 분위기가 좀 달랐다. 좋다 안 좋다가 아니라, 달랐다. 장인 장모님이 풍선을 불고 파티 형식으로 축하해 주었다. 좋았다. 다만 어색했다."),
      MIX([["그리고 나는 두 아이의 아빠가 됐다. 아이들이 자라면서 나의 진짜 생일이 필요하다고 느꼈다. 부모가 태어난 것을 축하해 주고 사랑을 줘야 아이가 자신의 탄생을 더 값지고 중요하게 생각할 거라고 믿었다. 그러려면 부모의 생일을 알려 주고 축하하는 법도 알려 줘야 했다. 그러자면 내 생일부터 정해야 했다. 11월 3일, 주민등록번호의 날짜로 하기로 했다. ", false], ["사십 년 넘게 못 정하던 것을 아이 때문에 정했다.", true]]),
      P("그런데 딸은 10월 30일에 축하를 해 준다. 내가 실제로 태어난 양력 날짜다. 누가 알려 준 것인지 나는 묻지 않았다. 아침에 초등학교 3학년의 간결한 문자가 왔고, 울퉁불퉁한 글씨의 편지와 몇천 원짜리 메모지, 샤프를 받았다."),
      P("“아빠 생일 축하해! 맛있는 것도 사 주는 것도 너무 고마워. 아빠도 오늘 생일 밥도 많이 먹고. 세상에서 기분 좋은 하루 보내. 다시 한번 생일 축하해. 2026년 10월 30일, 하연이가.”"),
      MIX([["맞춤법은 틀렸고 날짜는 맞았다.", true], [" 나에게 오늘은 그냥 그런 날이었는데, 나는 너무 행복해진다. 이 나이까지 생일의 감동 없이 살아온 사람이다. 자식의 존재가 이런 것인가.", false]]),
      P("이제 내 생일도 소중하고 아내의 생일도 소중하고 딸과 아들의 생일도 소중하다. 태어남에 감사하고, 나를 낳아 준 부모님께 감사하고, 아이들을 낳아 준 아내에게 감사한다. 나는 이기적이고 감정에 크게 휘둘리지 않는 사람이었다. 아니, 어쩌면 휘둘릴 일이 없었던 것뿐인지도 모른다."),
      P("비는 오지 않았다. 그 사실이면 충분한 하루다."),
    ],
  },
  {
    no: "07", title: "별", date: "2026년 11월 13일",
    paragraphs: [
      B("10개월이 지나가고 있다."),
      P("벌써 내 책상 위에서 여러 번 시도했다 포기한 책이 있다. 칼 세이건의 『코스모스』였다. 우주의 신비를 통해 인간 존재의 의미를 묻는 위대한 책이라 했다. 처음에는 광활한 은하의 크기에 잠시 압도당했다. 그러나 10장을 채 넘기지 못했다. 우주의 밀도와 별의 운동에 대한 장대한 설명 앞에서, 나는 자주 꾸벅꾸벅 졸았다. 부끄러웠다. 위대한 우주적 사유가 당장의 수면욕조차 이기지 못하다니."),
      P("나는 과학의 위대함을 부정하지 않는다. 다만, 그 신비로움이 내일 당장 쳐내야 할 공문이나 팍팍한 삶의 피로보다 절실하게 다가오지 않았을 뿐이다. 책을 덮으며 문득 궁금해졌다. 우주의 본질을 사색하던 고대의 철학자들은 과연 누구였을까. 그들은 적어도 먹고사는 일에 목을 매거나 생존을 위해 모든 에너지를 소진해야 하는 사람들은 아니었을 것이다."),
      MIX([["고대 세계의 지식을 집대성한 알렉산드리아 도서관을 읽을 때도 비슷한 생각이 들었다. 누군가 별의 궤도를 계산할 때, 그 공간을 청소하고 무거운 양피지를 나르던 사람들은 무슨 생각을 했을까. 아리스토텔레스가 관조적 삶을 예찬할 때, 그 여유는 누군가의 땀방울을 딛고 선 불평등의 결과물이었을지도 모른다. ", false], ["어쩌면 위대한 지적 성취란 모두에게 열린 것이 아니라, 타인의 노동을 딛고 설 수 있었던 소수의 특권이었을지도 모른다.", true], [" 아니, 어쩌면 지금 나의 이 알량한 사색조차 교사라는 밥벌이가 지탱해주고 있기 때문일 것이다.", false]]),
      MIX([["책은 위대한 과학적 성취를 말하면서도, 동시에 핵무기의 위험을 경고하며 인류 모두의 책임을 묻는다. 여기서 나는 다시 한번 불편해졌다. 전쟁에 쓸 무기를 만들게 하고 버튼을 누를 권한은 극소수 권력자에게 있는데, 왜 책임은 평범한 사람들의 몫이어야 하는가. 결정권이 없는 이들에게 던져진 ‘인류 공동의 운명’이라는 말은 공허했다. ", false], ["사색할 여유가 평등하지 않았듯, 미래를 결정할 권력 또한 평등하지 않다.", true]]),
      MIX([["“별 볼 일 없는 인간이, 별 볼 일 있는 우주를 관찰하기 시작했다.” 책을 읽으며 우주 앞에서는 한없이 작은 먼지 같은 인간의 특별함을 짚어낸 문장이라 생각했다. 그런데 이 말을 혀끝에서 굴리다 보니 뜻이 뒤집혔다. ", false], ["별 볼 일 없던 인간이, 마침내 ‘별을 볼 줄 아는’ 인간이 되었다.", true], [" 분명 위대한 도약이다. 하지만 여전히 모든 인간에게 별을 볼 자유와 여유가 주어진 것은 아니다.", false]]),
      P("누군가는 저 먼 우주를 개척하며 인류의 미래를 도모할 것이다. 그러나 나는 우주의 신비보다, 당장 내 앞의 우리 자식들의 학원비, 마이너스 통장 같은 나의 미래가 걱정되고 근심이 될 뿐이다."),
      P("별은.... 굳이 안 봐도 될 것 같다."),
    ],
  },
];

type SavedEntry = { id: string; title: string; date: string; body: string; created_at: string };

async function callApi(action: string, args: Record<string, unknown>) {
  const res = await fetch("actions", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ action, args }),
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok || json.error) throw new Error(json.error || "저장 기능을 불러오지 못했습니다.");
  return json.data;
}
async function createRow(row: Record<string, unknown>) {
  return callApi("records.create", { collection: "manuscript_entries", value: row, idempotency_key: `entry-${Date.now()}-${Math.random().toString(36).slice(2, 8)}` });
}

export default function App() {
  const [active, setActive] = useState("01");
  const [indexOpen, setIndexOpen] = useState(false);
  const [owner, setOwner] = useState(false);
  const [pwOpen, setPwOpen] = useState(false);
  const [pw, setPw] = useState("");
  const [pwError, setPwError] = useState("");
  const [saved, setSaved] = useState<SavedEntry[]>([]);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [formOpen, setFormOpen] = useState(false);
  const [fTitle, setFTitle] = useState("");
  const [fDate, setFDate] = useState("");
  const [fBody, setFBody] = useState("");
  const [result, setResult] = useState<{ saved: number; remaining: number; error: string | null; reloadError: string | null } | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);
  const refs = useRef<Record<string, HTMLElement | null>>({});

  async function reloadRecords() {
    try {
      const data = await callApi("records.list", { collection: "manuscript_entries" });
      const list: SavedEntry[] = (data.records || []).map((r: any) => ({ id: r.id, title: r.value.title || "제목 없는 글", date: r.value.date || "", body: r.value.body || "", created_at: r.created_at }));
      setSaved(list);
      setLoadError(null);
    } catch (e) {
      setLoadError(e instanceof Error ? e.message : String(e));
    }
  }

  useEffect(() => { reloadRecords(); }, []);

  const allChapters = useMemo(() => {
    const extra: Chapter[] = saved.map((s, i) => ({
      no: String(8 + i).padStart(2, "0"),
      title: s.title,
      date: s.date,
      paragraphs: s.body.split(/\n\s*\n/).filter(Boolean).map((t) => [{ t: t.trim() }]),
    }));
    return [...CHAPTERS, ...extra];
  }, [saved]);

  const goTo = (no: string) => {
    setActive(no);
    setIndexOpen(false);
    const el = refs.current[no];
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const unlock = () => {
    if (pw === "1720") {
      setOwner(true); setPwOpen(false); setPwError(""); setPw("");
    } else setPwError("비밀번호가 맞지 않습니다. 다시 입력해 주세요.");
  };

  const saveEntry = async () => {
    if (!fTitle.trim() || !fBody.trim()) { setResult({ saved: 0, remaining: 1, error: "제목과 본문을 모두 입력해 주세요.", reloadError: null }); return; }
    const rows = [{ title: fTitle.trim(), date: fDate.trim() || "날짜 미정", body: fBody.trim(), kind: "continuation" }];
    setBusy(true);
    let savedCount = 0; let error: string | null = null;
    try {
      for (const row of rows) { await createRow(row); savedCount += 1; }
    } catch (e) { error = e instanceof Error ? e.message : String(e); }
    let reloadError: string | null = null;
    try { await reloadRecords(); } catch (e) { reloadError = e instanceof Error ? e.message : String(e); }
    setResult({ saved: savedCount, remaining: rows.length - savedCount, error, reloadError });
    setBusy(false);
    if (!error) { setFormOpen(false); setFTitle(""); setFDate(""); setFBody(""); }
  };

  const deleteEntry = async (id: string) => {
    setBusy(true);
    try { await callApi("records.delete", { collection: "manuscript_entries", id }); await reloadRecords(); setConfirmDelete(null); }
    catch (e) { setResult({ saved: 0, remaining: 0, error: e instanceof Error ? e.message : String(e), reloadError: null }); }
    setBusy(false);
  };

  const current = allChapters.find((c) => c.no === active) || allChapters[0];

  return (
    <div data-safe-area-inset-root style={{ boxSizing: "border-box", paddingTop: "var(--safe-area-inset-top)", minHeight: "100vh", background: "var(--paper)" }} className="overflow-x-clip">
      {/* Header */}
      <header data-safe-area-sticky-top style={{ top: "var(--safe-area-inset-top)" }} className="sticky z-30 border-b border-[var(--line)] bg-[var(--paper)]/95 backdrop-blur">
        <div className="mx-auto flex max-w-[1180px] items-center justify-between gap-3 px-4 py-3 sm:px-6">
          <button onClick={() => goTo("01")} className="flex items-center gap-2 text-left">
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-[var(--ink)] text-[var(--paper)]"><Feather size={17} /></span>
            <span className="leading-none"><span className="block text-[17px] font-black tracking-tight">계속 쓴 글</span><span className="sans mt-1 block text-[11px] text-[var(--muted)]">누적 원고 · 01—07</span></span>
          </button>
          <div className="flex items-center gap-2">
            <button onClick={() => setIndexOpen(!indexOpen)} className="sans rounded-full border border-[var(--line)] bg-[var(--surface)] px-3 py-2 text-[12px] font-bold lg:hidden">INDEX {indexOpen ? "닫기" : "열기"}</button>
            {owner ? (
              <span className="sans inline-flex items-center gap-1.5 rounded-full bg-[var(--accent-soft)] px-3 py-2 text-[12px] font-bold text-[var(--accent)]"><Check size={13} /> 소유자 모드</span>
            ) : (
              <button onClick={() => setPwOpen(true)} className="sans inline-flex items-center gap-1.5 rounded-full bg-[var(--ink)] px-3.5 py-2 text-[12px] font-bold text-[var(--paper)]"><KeyRound size={13} /> 소유자 모드</button>
            )}
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="border-b border-[var(--line)]">
        <div className="mx-auto max-w-[1180px] px-4 pb-8 pt-8 sm:px-6 sm:pt-12">
          <p className="sans text-[11px] font-bold tracking-[0.22em] text-[var(--accent)]">PERSONAL ESSAY MANUSCRIPT · CUMULATIVE 01—07</p>
          <h1 className="mt-4 text-[clamp(44px,9vw,92px)] font-black leading-[0.98] tracking-[-0.04em]">계속 쓴 글</h1>
          <p className="mt-4 text-[19px] font-semibold text-[var(--ink-soft)] sm:text-[22px]">잘 쓴 글이 아니라 계속 쓴 글</p>
          <p className="mt-5 max-w-[720px] text-[15px] leading-[1.9] text-[var(--ink-soft)]">빠진 날은 빠진 채로 두고, 지우고 싶은 날도 지우지 않기로 했다. 교실과 교무실, 집으로 돌아오는 길에서 건져 올린 일곱 편의 기록을 순서대로 모아둔다.</p>
          <div className="mt-7 flex flex-wrap items-center gap-2">
            <button onClick={() => goTo("01")} className="sans rounded-full bg-[var(--accent)] px-4 py-2.5 text-[13px] font-bold text-white">처음부터 읽기 →</button>
            <button onClick={() => goTo("07")} className="sans rounded-full border border-[var(--line)] bg-[var(--surface)] px-4 py-2.5 text-[13px] font-bold">최신 글 07 별 보기</button>
            <span className="sans ml-1 text-[12px] text-[var(--muted)]">7편 · 2026년 10월 18일 — 11월 13일</span>
          </div>
        </div>
      </section>

      <main className="mx-auto grid max-w-[1180px] grid-cols-1 gap-0 px-4 sm:px-6 lg:grid-cols-[280px_1fr] lg:gap-10">
        {/* INDEX */}
        <aside className={`${indexOpen ? "block" : "hidden"} lg:block lg:pt-8`}>
          <div className="lg:sticky lg:top-[96px]">
            <div className="flex items-baseline justify-between border-b-2 border-[var(--ink)] pb-3">
              <h2 className="sans text-[13px] font-black tracking-[0.18em]">INDEX</h2>
              <span className="sans text-[11px] text-[var(--muted)]">목차</span>
            </div>
            <nav className="mt-2 flex flex-col" aria-label="목차">
              {allChapters.map((c) => (
                <button key={c.no} onClick={() => goTo(c.no)} className={`index-link ${active === c.no ? "active" : ""} flex items-baseline gap-3 rounded-xl border border-transparent px-3 py-3 text-left transition`}>
                  <span className="sans w-7 shrink-0 text-[13px] font-black tabular-nums">{c.no}</span>
                  <span className="min-w-0 flex-1"><span className="block truncate text-[15px] font-bold">{c.title}</span><span className="index-date sans block text-[11px] text-[var(--muted)]">{c.date}</span></span>
                  <ChevronRight size={14} className="shrink-0 opacity-50" />
                </button>
              ))}
            </nav>
            <div className="mt-5 rounded-2xl border border-[var(--line)] bg-[var(--paper-2)] p-4">
              <p className="sans text-[12px] font-bold">읽는 방법</p>
              <p className="mt-1.5 text-[13px] leading-relaxed text-[var(--ink-soft)]">굵은 문장은 그날의 갈고리다. 처음 문장부터 천천히, 건너뛰지 않고 읽어도 좋다.</p>
              <p className="sans mt-3 border-t border-[var(--line)] pt-3 text-[11px] leading-relaxed text-[var(--muted)]">저장 공간은 최대 1,000개 기록, 기록당 16KB까지입니다.</p>
            </div>
            {owner && (
              <button onClick={() => setFormOpen(true)} className="sans mt-3 flex w-full items-center justify-center gap-2 rounded-xl bg-[var(--accent)] px-4 py-3 text-[13px] font-bold text-white"><Plus size={15} /> 이어서 쓰기</button>
            )}
          </div>
        </aside>

        {/* Reading column */}
        <div className="min-w-0 pb-16 pt-8 lg:pt-10">
          {/* Owner banner */}
          {owner ? (
            <div className="mb-6 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[var(--line)] bg-[var(--accent-soft)] px-4 py-3">
              <p className="sans text-[13px] font-bold text-[var(--accent)]">소유자 모드가 열려 있습니다. 이어쓰기를 추가하거나 저장된 이어쓰기를 지울 수 있습니다.</p>
              <div className="flex gap-2">
                <button onClick={() => setFormOpen(true)} className="sans rounded-full bg-[var(--ink)] px-3 py-1.5 text-[12px] font-bold text-[var(--paper)]">새 글 쓰기</button>
                <button onClick={() => setOwner(false)} className="sans rounded-full border border-[var(--line)] bg-[var(--surface)] px-3 py-1.5 text-[12px] font-bold">모드 닫기</button>
              </div>
            </div>
          ) : null}

          {loadError && (
            <div className="sans mb-6 rounded-2xl border border-[var(--line)] bg-[var(--surface)] px-4 py-3 text-[12px] text-[var(--ink-soft)]">이어쓰기 목록을 불러오지 못했습니다. 기본 원고 01—07은 그대로 읽을 수 있습니다.</div>
          )}
          {result && (
            <div className="sans mb-6 rounded-2xl border border-[var(--line)] bg-[var(--surface)] px-4 py-3 text-[13px]">
              <p><strong>저장 {result.saved}개</strong> · 남은 {result.remaining}개</p>
              {result.error && <p className="mt-1 text-[var(--accent)]">저장 오류: {result.error}</p>}
              {result.reloadError && <p className="mt-1">다시 불러오기 오류: {result.reloadError}</p>}
              {!result.error && result.saved > 0 && <p className="mt-1 text-[var(--ink-soft)]">저장이 확인되었습니다.</p>}
              <button onClick={() => setResult(null)} className="mt-2 text-[12px] font-bold underline">닫기</button>
            </div>
          )}

          {allChapters.map((ch, idx) => {
            const isSaved = idx >= CHAPTERS.length;
            const savedId = isSaved ? saved[idx - CHAPTERS.length]?.id : null;
            return (
              <article key={ch.no} ref={(el) => { refs.current[ch.no] = el; }} className="chapter-anchor border-t border-[var(--line)] py-10 first:border-t-0 first:pt-0">
                <div className="flex flex-wrap items-end justify-between gap-3">
                  <div className="flex items-baseline gap-3">
                    <span className="sans text-[13px] font-black tracking-[0.2em] text-[var(--accent)]">{ch.no}</span>
                    <h2 className="text-[clamp(28px,6vw,44px)] font-black leading-none tracking-tight">{ch.title}</h2>
                  </div>
                  <p className="sans text-[13px] font-medium text-[var(--muted)]">{ch.date}</p>
                </div>
                {isSaved && <p className="sans mt-2 inline-block rounded-full bg-[var(--paper-2)] px-2.5 py-1 text-[11px] font-bold text-[var(--ink-soft)]">소유자가 이어 쓴 글</p>}
                <div className="manuscript-body mt-7 max-w-[720px]">
                  {ch.paragraphs.map((para, pi) => (
                    <p key={pi}>{para.map((s, si) => s.b ? <strong key={si}>{s.t}</strong> : <span key={si}>{s.t}</span>)}</p>
                  ))}
                </div>
                <div className="mt-6 flex flex-wrap items-center gap-2">
                  <span className="sans text-[11px] tracking-[0.18em] text-[var(--muted)]">— {ch.no} 끝</span>
                  {idx < allChapters.length - 1 && <button onClick={() => goTo(allChapters[idx + 1].no)} className="sans rounded-full border border-[var(--line)] bg-[var(--surface)] px-3 py-1.5 text-[12px] font-bold">다음 {allChapters[idx + 1].no} {allChapters[idx + 1].title} →</button>}
                  {owner && isSaved && savedId && (
                    confirmDelete === savedId ? (
                      <span className="sans flex items-center gap-2 text-[12px]"><span>정말 지울까요?</span><button disabled={busy} onClick={() => deleteEntry(savedId)} className="rounded-full bg-[var(--accent)] px-3 py-1.5 font-bold text-white">지우기</button><button onClick={() => setConfirmDelete(null)} className="rounded-full border px-3 py-1.5 font-bold">취소</button></span>
                    ) : (
                      <button onClick={() => setConfirmDelete(savedId)} className="sans inline-flex items-center gap-1 rounded-full border border-[var(--line)] px-3 py-1.5 text-[12px] font-bold text-[var(--ink-soft)]"><Trash2 size={13} /> 이어쓰기 지우기</button>
                    )
                  )}
                </div>
              </article>
            );
          })}

          <footer className="mt-4 rounded-3xl border border-[var(--line)] bg-[var(--paper-2)] p-6">
            <p className="flex items-center gap-2 text-[15px] font-bold"><BookOpen size={16} /> 여기까지가 지금까지의 누적 원고입니다.</p>
            <p className="mt-2 text-[14px] leading-relaxed text-[var(--ink-soft)]">별은 굳이 안 봐도 될 것 같다 — 고 쓴 날 뒤에도 글은 계속된다. 다음 날의 문장이 이 자리에 이어질 것이다.</p>
            {owner && <button onClick={() => setFormOpen(true)} className="sans mt-4 rounded-full bg-[var(--ink)] px-4 py-2.5 text-[13px] font-bold text-[var(--paper)]">이어서 쓰기</button>}
          </footer>
        </div>
      </main>

      {/* Password dialog */}
      {pwOpen && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/45 p-4 sm:items-center" role="dialog" aria-modal="true" aria-label="소유자 모드">
          <div className="w-full max-w-[420px] rounded-3xl bg-[var(--surface)] p-6 shadow-2xl">
            <div className="flex items-start justify-between gap-3">
              <div><h3 className="text-[20px] font-black">소유자 모드</h3><p className="sans mt-1 text-[13px] text-[var(--ink-soft)]">이어쓰기를 추가할 수 있는 모드입니다.</p></div>
              <button onClick={() => { setPwOpen(false); setPwError(""); }} aria-label="닫기" className="rounded-full border border-[var(--line)] p-2"><X size={16} /></button>
            </div>
            <label className="sans mt-5 block text-[12px] font-bold">비밀번호</label>
            <div className="mt-2 flex gap-2">
              <input type="password" inputMode="numeric" value={pw} onChange={(e) => setPw(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") unlock(); }} placeholder="비밀번호 4자리" className="min-w-0 flex-1 rounded-xl border border-[var(--line)] bg-[var(--paper)] px-3 py-3 text-[15px] outline-none focus:border-[var(--accent)]" />
              <button onClick={unlock} className="sans shrink-0 rounded-xl bg-[var(--ink)] px-4 py-3 text-[13px] font-bold text-[var(--paper)]">열기</button>
            </div>
            {pwError && <p className="sans mt-2 text-[12px] font-bold text-[var(--accent)]">{pwError}</p>}
            <p className="sans mt-4 flex items-center gap-1.5 text-[11px] text-[var(--muted)]"><Lock size={12} /> 비밀번호는 이 기기에 저장되지 않습니다.</p>
          </div>
        </div>
      )}

      {/* New entry dialog */}
      {formOpen && owner && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/45 p-4 sm:items-center" role="dialog" aria-modal="true" aria-label="이어서 쓰기">
          <div className="max-h-[92vh] w-full max-w-[620px] overflow-y-auto rounded-3xl bg-[var(--surface)] p-6 shadow-2xl">
            <div className="flex items-start justify-between gap-3">
              <div><h3 className="flex items-center gap-2 text-[20px] font-black"><PenLine size={18} /> 이어서 쓰기</h3><p className="sans mt-1 text-[13px] text-[var(--ink-soft)]">빈 줄로 문단을 나눠 주세요. 저장된 글은 목차 뒤에 이어집니다.</p></div>
              <button onClick={() => setFormOpen(false)} aria-label="닫기" className="rounded-full border border-[var(--line)] p-2"><X size={16} /></button>
            </div>
            <label className="sans mt-5 block text-[12px] font-bold">제목</label>
            <input value={fTitle} onChange={(e) => setFTitle(e.target.value)} placeholder="예: 월요일" className="mt-2 w-full rounded-xl border border-[var(--line)] bg-[var(--paper)] px-3 py-3 text-[15px] outline-none focus:border-[var(--accent)]" />
            <label className="sans mt-4 block text-[12px] font-bold">날짜 (예: 2026년 11월 14일)</label>
            <input value={fDate} onChange={(e) => setFDate(e.target.value)} placeholder="2026년 11월 14일" className="mt-2 w-full rounded-xl border border-[var(--line)] bg-[var(--paper)] px-3 py-3 text-[15px] outline-none focus:border-[var(--accent)]" />
            <label className="sans mt-4 block text-[12px] font-bold">본문</label>
            <textarea value={fBody} onChange={(e) => setFBody(e.target.value)} rows={10} placeholder={"첫 문장을 적어 보세요.\n\n빈 줄로 문단을 나눕니다."} className="mt-2 w-full rounded-xl border border-[var(--line)] bg-[var(--paper)] px-3 py-3 text-[15px] leading-relaxed outline-none focus:border-[var(--accent)]" />
            <button disabled={busy} onClick={saveEntry} className="sans mt-4 w-full rounded-xl bg-[var(--accent)] px-4 py-3.5 text-[14px] font-bold text-white disabled:opacity-50">{busy ? "저장하는 중…" : "저장하고 원고에 이어 붙이기"}</button>
            <p className="sans mt-3 text-center text-[11px] text-[var(--muted)]">저장이 확인된 뒤에만 원고에 나타납니다.</p>
          </div>
        </div>
      )}
    </div>
  );
}
